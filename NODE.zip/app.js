const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());


const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', 
  database: 'dldii'
});


connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL successfully!');
});

// เส้นทางสำหรับตรวจสอบการทำงานของเซิร์ฟเวอร์
app.get('/', (req, res) => {
  res.send('Welcome to Product management system');
});

// เส้นทางสำหรับดึงข้อมูลสินค้า (READ)
app.get('/products', (req, res) => {
  const query = 'SELECT * FROM product';
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching items:', err);
      return res.status(500).json({ message: 'Error fetching items' });
    }
    res.json(results);
  });
});

// เส้นทางสำหรับเพิ่มสินค้าใหม่ (CREATE)
app.post('/products', (req, res) => {
  const items = req.body;
  const query = `INSERT INTO product (productName, price, qty) VALUES ('${items.productName}', ${items.price}, ${items.qty})`;
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error creating items:', err);
      return res.status(500).json({ message: 'Error creating items' });
    }
    res.status(201).json({ id: results.insertId, productName: items.productName });
  });
});

// เส้นทางสำหรับอัปเดตสินค้า (UPDATE)
app.put('/products/:id', (req, res) => {
  const id = req.params.id;
  const items = req.body;
  const query = `UPDATE product SET productName = '${items.productName}', price = ${items.price}, qty = ${items.qty} WHERE productID = ${id}`;
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error updating item:', err);
      return res.status(500).json({ message: 'Error updating item' });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Item not found' });
    }
    res.json({ message: 'Item updated successfully' });
  });
});

// เส้นทางสำหรับลบสินค้า (DELETE)
app.delete('/products/:id', (req, res) => {
  const id = req.params.id;
  const query = `DELETE FROM product WHERE productID = ${id}`;
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error deleting item:', err);
      return res.status(500).json({ message: 'Error deleting item' });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Item not found' });
    }
    res.json({ message: 'Item deleted successfully' });
  });
});

// เริ่มต้นเซิร์ฟเวอร์
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
