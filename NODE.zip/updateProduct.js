const apiUrl = 'http://localhost:3000/products';

const updateProductForm = document.getElementById('updateProductForm');
const urlParams = new URLSearchParams(window.location.search);
const productId = urlParams.get('id');

// ฟังก์ชันสำหรับดึงข้อมูลสินค้าที่จะอัปเดต
function getProductForUpdate() {
  fetch(`${apiUrl}/${productId}`)
    .then(response => response.json())
    .then(data => {
      const product = data[0];
      updateProductForm.elements['productName'].value = product.productName;
      updateProductForm.elements['price'].value = product.price;
      updateProductForm.elements['qty'].value = product.qty;
    })
    .catch(error => console.error('Error:', error));
}

// ฟังก์ชันสำหรับอัปเดตสินค้า
updateProductForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const formData = new FormData(updateProductForm);
  const productData = {
    productName: formData.get('productName'),
    price: parseFloat(formData.get('price')),
    qty: parseInt(formData.get('qty'))
  };

  fetch(`${apiUrl}/${productId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(productData)
  })
    .then(response => response.json())
    .then(data => {
      alert('Successfully updated the product');
      window.location.href = 'products.html';
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Failed to update the product');
    });
});

if (productId) {
  getProductForUpdate();
}
