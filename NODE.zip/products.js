const apiUrl = 'http://localhost:3000/products';

const productLists = document.getElementById('productLists');

// ฟังก์ชันสำหรับดึงรายการสินค้า
function getProductList() {
  fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
      productLists.innerHTML = '';
      data.forEach(product => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${product.productName}</td>
          <td>${product.price}</td>
          <td>${product.qty}</td>
          <td>
            <button class="btn_update" data-id="${product.productID}">Update</button>
            <button class="btn_delete" data-id="${product.productID}">Delete</button>
          </td>
        `;
        productLists.appendChild(row);
      });
      attachEventListeners();
    })
    .catch(error => console.error('Error:', error));
}

// ฟังก์ชันสำหรับแนบ event listeners
function attachEventListeners() {
  const updateButtons = document.querySelectorAll('.btn_update');
  updateButtons.forEach(button => {
    button.addEventListener('click', () => {
      const productId = button.getAttribute('data-id');
      window.location.href = `updateProduct.html?id=${productId}`;
    });
  });

  const deleteButtons = document.querySelectorAll('.btn_delete');
  deleteButtons.forEach(button => {
    button.addEventListener('click', () => {
      const productId = button.getAttribute('data-id');
      deleteProduct(productId);
    });
  });
}

// ฟังก์ชันสำหรับลบสินค้า
function deleteProduct(id) {
  if (confirm('Are you sure you want to delete this product?')) {
    fetch(`${apiUrl}/${id}`, {
      method: 'DELETE'
    })
      .then(response => response.json())
      .then(data => {
        alert(data.message);
        getProductList();
      })
      .catch(error => console.error('Error:', error));
  }
}

getProductList();
