const apiUrl = 'http://localhost:3000/products';

const addProductForm = document.getElementById('addProductForm');

addProductForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const formData = new FormData(addProductForm);
  const productData = {
    productName: formData.get('productName'),
    price: parseFloat(formData.get('price')),
    qty: parseInt(formData.get('qty'))
  };

  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(productData)
  })
    .then(response => response.json())
    .then(data => {
      alert('Successfully added the new product');
      window.location.href = 'products.html';
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Failed to add the new product');
    });
});
